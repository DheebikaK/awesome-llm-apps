
from .ai_consultant_agent import root_agent

# Export for ADK CLI discovery
__all__ = ['root_agent'] 