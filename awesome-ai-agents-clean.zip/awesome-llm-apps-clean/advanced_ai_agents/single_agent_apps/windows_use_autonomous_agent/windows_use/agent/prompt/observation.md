```xml
<Observation>
Execution Step: ({steps}/{max_steps})

Action Response: {observation}

[Start of Desktop State]

Cursor Location: {cursor_location}

Foreground Application: {active_app}

Opened Applications:
{apps}

List of Interactive Elements:
{interactive_elements}

List of Scrollable Elements:
{scrollable_elements}

List of Informative Elements:
{informative_elements}

[End of Desktop State]

Note: Use the Done Tool if the task is completely over else continue solving.
</Observation>
```