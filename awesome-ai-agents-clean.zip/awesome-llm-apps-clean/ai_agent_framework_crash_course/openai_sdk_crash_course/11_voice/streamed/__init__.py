# Streaming voice agent example
